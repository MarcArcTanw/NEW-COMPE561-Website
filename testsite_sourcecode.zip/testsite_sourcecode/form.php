<?php
    if(isset($_POST['submit']))
    {
        $firstname = $_POST['fname'];
        $lastname = $_POST['lname'];
        $address1 = $_POST['address1'];
        $address2 = $_POST['address2'];
        $state = $_POST['state'];
        $zip = $_POST['zip'];
        $favMCU = $_POST['favMCU'];
        
        $host = "localhost";
        $username = "formdb_user";
        $password = "IBurntMyT0astATD1sney2325$";
        $dbname = "form_entriesdb";
        
        $con = mysqli_connect($host, $username, $password, $dbname);
        
        if (!$con)
        {
            die("Connection failed!" . mysqli_connect_error());
        }
        
        $sql = "INSERT INTO userinfo (id, fname_fld, lname_fld, address1_fld, address2_fld, state_fld, zip_fld, favMCU_fld) 
        VALUES ('0', '$firstname', '$lastname', '$address1', '$address2', '$state', '$zip', '$favMCU')";
        
        $rs = mysqli_query($con, $sql);
        if($rs)
        {
            header( "Location: Success.html" );
        }
        
        mysqli_close($con);
    }
?>
